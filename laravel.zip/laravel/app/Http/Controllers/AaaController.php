<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class AaaController extends Controller
{
    public function aaa(Request $Request){
        $arr = $Request->input();
        // print_r ($arr);
        return view('aaa.aaa');
    }


    public function ddd(){
        $url = url('ddd1');
        return redirect($url);
    }
    public function ddd1(){
        echo "少时诵诗书世十";
    }

    public function deom(Request $Request){
        /**添加 */
        // $sql = "insert into deom set name='哈哈哈',tel=2000";
        // $arr = DB::insert($sql);
        // var_dump($arr);

        /**查询 */
        // $sql = 'select * from deom';
        // $arr = DB::select($sql);
        // foreach ($arr as $k=>$v){
        //     echo $v->id;
        //     echo $v->name;
        // }

        /**修改 */
        // $sql = "update deom set name='小星星',tel='110' where id=1";
        // $arr = DB::update($sql);
        // var_dump($arr);

        /**删除 */
        // $sql = "delete from deom where id=1";
        // $arr = DB::delete($sql);
        // var_dump($arr);
    }


}