<?php

namespace App\Http\Controllers\Goods;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\cart;
use App\Models\goods;


class AddressController extends Controller
{
    public function address(Request $request){
        $arr = DB::table('order_address')->where('is_del',1)->get();
        return view('goods.address',['arr'=>$arr]);
    }
    /**删除 */
    public function addressDel(Request $request){
        $session_id = $request->session()->get('user_id');
        if (!empty($session_id)) {
            $address_id = $request->input('address_id');
            // var_dump($id);exit;
            // if (empty($address_id)) {
            //     $arr = ['status'=>0,'msg'=>'请选择要删除的商品'];
            //     return $arr;
            // }
            $data = [
                'is_del'=>2,
            ];
            $arr = DB::table('order_address')->where('address_id',$address_id)->update($data);
            if($arr){
                $arr = ['status'=>1,'msg'=>'删除成功'];
                return $arr;
            }else{
                $arr = ['status'=>0,'msg'=>'删除失败'];
                return $arr;
            }
        }
    }
    /**修改 */
    public function addupd(Request $request){
        $address_id=$request->input('address_id');
        $arr = DB::table('order_address')->where('address_id','=',$address_id)->first();
        // $sql="select * from user_cate";
        // $res=DB::select($sql);
        return view('goods.adsupd',['arr'=>$arr]);
    }
    public function addressupd(Request $request){
        $address_id = $request->input('address_id');
        // print_r($address_id);die;
        $data = $request->input();
        $session_id  = $request->session()->get('user_id');
        // print_r($data);
        $info = [
            'user_id'=>$session_id,
            'consignee_name' => $data['consignee_name'],
            'consignee_tel' => $data['consignee_tel'],
            'detailed_address' => $data['detailed_address'],
            'add_province'=>$data['add_province'],
            'status'=>$data['status'],
        ];
        // print_r($info);die;
        $res = DB::table('order_address')->where('address_id',$address_id)->update($info);

        if($res){
            $arr = ['status'=>1,'msg'=>'修改成功'];
            return $arr;
        }else{
            $arr = ['status'=>0,'msg'=>'修改失败'];
            return $arr;
        }
    }
    public function defalt(Request $request){
        $address_id = $request->input('address_id');
        $session_id  = $request->session()->get('user_id');

        $ainfo = [
            
            'status'=>2,
        ];
        $binfo = [
            
            'status'=>1,
        ];
        // print_r($data);exit;
        $res = DB::table('order_address')->where('user_id',$session_id)->update($ainfo);
        $arr = DB::table('order_address')->where('address_id',$address_id)->update($binfo);
        if($res){
            $arr = ['status'=>1,'msg'=>'设置成功'];
            return $arr;
        }else{
            $arr = ['status'=>0,'msg'=>'设置失败'];
            return $arr;
        }

    }




    public function site(){
        return view('goods.site'); 
    }



    public function siteadd(Request $request){  
        $session_id  = $request->session()->get('user_id');
        
        $data=$request->input();
        if ($session_id) {
            $info = [
                'user_id'=>$session_id,
                'consignee_name' => $data['consignee_name'],
                'consignee_tel' => $data['consignee_tel'],
                'detailed_address' => $data['detailed_address'],
                'add_province'=>$data['add_province'],
                'status'=>$data['status'],
            ];
 
            $res=DB::table('order_address')->insert($info);

            if($res){
                $arr = ['status'=>1,'msg'=>'保存成功'];
                return $arr;
            }
        }else{
            return  array('status'=>1,"msg"=>"请先登录");
        }
    }
}