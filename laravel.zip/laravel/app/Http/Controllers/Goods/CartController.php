<?php

namespace App\Http\Controllers\Goods;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\cart;
use App\Models\goods;


class CartController extends Controller
{
    public function addcart(Request $request){
        $session_id = $request->session()->get('user_id');
        if ($session_id) {
            $arr = cart::join('goods','goods.goods_id','=','cart.goods_id')->where('user_id',$session_id)->where('is_del',1)->get();
            //var_dump($arr);

            // $arr = DB::table('goods')
            //     ->join('cart','goods.goods_id','=','cart.goods_id')
            //     ->get();

            $goodsWhere=[
                'goods_hot'=>1
            ];
            $res=goods::where($goodsWhere)->orderBy('goods_salenum','desc')->limit(4)->get();
            return view('goods.cart',['arr'=>$arr,'res'=>$res]);
        }else{
            echo "请先登录";
            return redirect('login');
        }

    }
    /**批删 */
    public function cartAll(Request $request){
        $session_id = $request->session()->get('user_id');
        if ($session_id) {
            $goods_id = $request->input('goods_id');
            // print_r($goods_id);exit;
            $goods_id = ltrim($goods_id,',');
            $goods_id = explode(',',$goods_id);
            $carUpdate = [
                'is_del'=>2,
                'buy_number'=>0
            ];
            $res = cart::whereIn('goods_id',$goods_id)->where('user_id',$session_id)->update($carUpdate);
            if($res){
                $arr = array(
                    'status'=>1,
                    'msg'=>'删除成功'
                );
                return $arr;

            }else{
                $arr = ['status'=>0,'msg'=>'删除失败'];
                return $arr;
            }
        }else{
            return  array('status'=>1,"msg"=>"请先登录");
        }
    }


    /**单删 */
    public function cartDel(Request $request){
        $session_id = $request->session()->get('user_id');
        if ($session_id) {
            $id = $request->input('id',0,'intval');
            // var_dump($id);exit;
            if (empty($id)) {
                $arr = ['status'=>0,'msg'=>'请选择要删除的商品'];
                return $arr;
            }
            $data = [
                'is_del'=>2,
                'buy_number'=>0
            ];
            $arr = cart::where('id',$id)->update($data);

            // var_dump($res);exit;
            if($arr){
                $arr = ['status'=>1,'msg'=>'删除成功'];
                return $arr;
            }else{
                $arr = ['status'=>0,'msg'=>'删除失败'];
                return $arr;
            }
        }else{
            return  array('status'=>1,"msg"=>"请先登录");
        }
    }

    /**减号 */
    public function cartmin(Request $request){
        $id = $request->input('id');
        $buy_number = $request->input('buy_number',0,'intval');
        $user_id = $request->session()->get('user_id');
        $arr = cart::where(['id'=>$id,'user_id'=>$user_id])->first();
        // print_r($arr);exit;
        $data = [
            'buy_number'=>$buy_number,
        ];
        $arr = cart::where(['id'=>$id,'user_id'=>$user_id])->update($data);
        if($arr){
            $arr = ['status'=>1,'msg'=>'修改成功'];
            return $arr;
        }else{
            $arr = ['status'=>0,'msg'=>'修改失败'];
            return $arr;
        }
    }

    /**加号 */
    public function cartadd(Request $request){
        $id = $request->input('id');
        $buy_number = $request->input('buy_number',0,'intval');
        $user_id = $request->session()->get('user_id');
        $arr = cart::where(['id'=>$id,'user_id'=>$user_id])->first();
        // print_r($arr);exit;
        $data = [
            'buy_number'=>$buy_number,
        ];
        $arr = cart::where(['id'=>$id,'user_id'=>$user_id])->update($data);
        if($arr){
            $arr = ['status'=>1,'msg'=>'修改成功'];
            return $arr;
        }else{
            $arr = ['status'=>0,'msg'=>'修改失败'];
            return $arr;
        }
    }

    

}
