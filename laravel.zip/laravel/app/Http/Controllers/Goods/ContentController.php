<?php

namespace App\Http\Controllers\Goods;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ContentController extends Controller
{
    public function content(Request $request){
        $goods_id=$request->input('goods_id');
        $arr = DB::table('goods')->where('goods_id',$goods_id)->get();
        return view('goods.content',['arr'=>$arr]);
    }


    public function cart(Request $request){
        $session_id = $request->session()->get('user_id');
        // var_dump($session);exit;
        if ($session_id) {
            $goods_id = $request->input('goods_id',0,'intval');
            $buy_number = $request->input('buy_number');
            if (empty($goods_id)) {
                $arr = ['status'=>0,'msg'=>'请选择要购买的商品'];
                return $arr;
            }
            if (empty($buy_number)) {
                $arr = ['status'=>0,'msg'=>'请选择购买的数量'];
                return $arr;
            }
            $goodsWhere=[
                'goods_id'=>$goods_id
            ];
            $goodsInfo = DB::table('goods')->where($goodsWhere)->first();
            $goods_num = $goodsInfo->goods_num;
            if(empty($goodsInfo)){
                $arr = ['status'=>0,'msg'=>'购买的商品不存在'];
                return $arr;
            }
            $cartWhere = [
                'goods_id'=>$goods_id,
                'user_id'=>$session_id,
            ];
            $cart = DB::table('cart')->where($cartWhere)->first();
            // print_r($cart);
            if ($cart) {
                $cartUpdate = [
                    'buy_number'=>$cart->buy_number+$buy_number,
                    'create_time'=>time(),
                    'is_del'=>1
                ];
                $cart_num = $cart->buy_number;
                if($cartUpdate['buy_number']>$goods_num){
                    $arr = ['status'=>0,'msg'=>'商品最多可选'.$goods_num.'件,购物车已有'.$cart_num.'件'];
                    return $arr;exit;
                }
                DB::table('cart')->where($cartWhere)->update($cartUpdate);

                $cartNumInfo = DB::table('cart')->where('user_id',$session_id)->get()->toArray();
                // print_r($cartNumInfo);
                $buy_num = array_column($cartNumInfo,'buy_number');
                $buy_number = array_sum($buy_num);

                $arr = ['status'=>1,'msg'=>'添加成功','num'=>$buy_number];
                return  $arr;
            }else{
                $insert=[
                    'goods_id'=>$goods_id,
                    // 'add_price'=>$goodsInfo->goods_selfprice,
                    'buy_number'=>$buy_number,
                    'user_id'=>$session_id,
                    'create_time'=>time(),
                ];
                if ($insert['buy_number']>$goods_num) {
                    $arr = ['status'=>0,'msg'=>'商品最多可选'.$goods_num.'件,请选择'];
                    return $arr;exit;
                }
                $res = DB::table('cart')->insert($insert);

                $cartNumInfo = DB::table('cart')->where('user_id',$session_id)->get()->toArray();
                $buy_num = array_column($cartNumInfo,'buy_number');
                $buy_number = array_sum($buy_num);
                if ($res) {
                    $arr = ['status'=>1,'msg'=>'添加成功','num'=>$buy_number];
                    return $arr;
                }else{
                    $arr = ['status'=>0,'msg'=>'添加失败'];
                    return $arr;
                } 
            }

        }else{
            return  array('status'=>1,"msg"=>"请先登录");
        }
    }
}
    

        // print_r($res);
        // return view('goods.cart');
