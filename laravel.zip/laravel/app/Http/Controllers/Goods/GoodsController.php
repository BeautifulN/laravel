<?php

namespace App\Http\Controllers\Goods;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Cate;
use App\Models\Goods;
class GoodsController extends Controller
{
    public function all(){

        $arrWhere = [
            'goods_up'=>1
        ];
        $arr = Goods::where($arrWhere)->get();


        $where = [
            'p_id'=>0,
        ];   
        $cate =Cate::where($where)->get();
        return view('goods.goods',['cate'=>$cate,'arr'=>$arr]);

    }

    public function cons(Request $request){
        $arr = [];
        $cate_id = $request->input('cate_id');

        $goodsWhere = Goods::orderBy('goods_salenum','desc');
        if ($cate_id) {
           $cateInfo =Cate::get();
        //    print_r($cateInfo);exit;
           $cate_id = $this->getCateId($cateInfo,$cate_id);
           $goodsWhere = $goodsWhere->whereIn('cate_id',$cate_id);

        };
        $goodsInfo = $goodsWhere->get();
        // print_r($goodsInfo);exit;


        $addview = view('goods.cons',['goodsInfo'=>$goodsInfo]);
        // $content = response($addview)->getContent();
        $content=response($addview)->getContent();


        $arr['info'] = $content;
        return $arr;
        
    }

    /** 获取当前分类下所有子类的id */
    public function getCateId($cateInfo,$p_id){
        static $cateId=[];
        foreach($cateInfo as $k=>$v){
            if($v['p_id']==$p_id){
                $cateId[]=$v['cate_id'];
                $this->getCateId($cateInfo,$v['cate_id']);
            }
        }
        return $cateId;
    }

    // public function cons(Request $request){
    //     $arr = array();
    //     $page = $request->input("page",1);
    //     $pageNum = 2;
    //     $offset = ($page-1) * $pageNum;
    //     $arrDataInfo = DB::table("shop_goods")->offset($offset)->limit($pageNum)->get();

    //     $totalData = DB::table("shop_goods")->count();
    //     $pageTotal = ceil($totalData/$pageNum);

    //     $objview = view('goods.cons',['info'=>$arrDataInfo]);

    //     $content = response($objview)->getContent();
    //     $arr['info']=$content;
    //     $arr['page']=$pageTotal;

    //     return  $arr;

    // }

}
