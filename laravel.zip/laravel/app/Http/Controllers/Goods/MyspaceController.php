<?php

namespace App\Http\Controllers\Goods;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\cart;
use App\Models\goods;


class MyspaceController extends Controller
{
    public function myspace(){

        return view('goods.myspace');


    }


}