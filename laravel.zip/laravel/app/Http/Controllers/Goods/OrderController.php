<?php

namespace App\Http\Controllers\Goods;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\cart;
use App\Models\goods;


class OrderController extends Controller
{

    public function order(Request $request){
        $id = $request->input('id');
        $yuan = $request->input('yuan');
        $goods_id = $request->input('goods_id');
        // print_r('goods_id');
        $session_id = $request->session()->get('user_id');
            if (empty($session_id)) {
                return redirect('login');
            }
            if (empty($goods_id)) {
                return redirect('goods');
            }

            $goods_id = ltrim($goods_id,',');
            $goods_id = explode(',',$goods_id);
            $data = DB::table('cart')->whereIn('goods_id',$goods_id)->where('user_id',$session_id)->get();
            foreach($data as $v){
                if ($v->goods_status!=1) {
                    return redirect('goods');
                }
            }
        $order_number = date("YmdHis",time()).rand(1000,9999);
        $order = [
            'order_number'=>$order_number,
            'user_id'=>$session_id,
            'order_amount'=>$yuan,
            'pay_type'=>1,
            'pay_status'=>1,
            'order_status'=>1,
            'pay_time'=>time(),

        ];
        $order_id= DB::table('order')->insertGetId($order);
        // print_r($res);exit;

        $arr = cart::whereIn('cart.goods_id',$goods_id)
            ->where('user_id',$session_id)
            ->join('goods','cart.goods_id','=','goods.goods_id')       
            ->get();

        $orderInfo = DB::table('order')->where('order_id',$order_id)->first();
        // print_r($orderInfo);exit;
        $order_id = $orderInfo->order_id;
        $order_detail = [];
        foreach($arr as $v){
            $order_detail = [
                'order_number'=>$order_number,
                'user_id'=>$session_id,
                'order_id'=>$order_id,
                'goods_id'=>$v->goods_id,
                'goods_img'=>$v->goods_img,
                'goods_name'=>$v->goods_name,
                'buy_number'=>$v->buy_number,

            ];
            $data = DB::table('order_detail')->insert($order_detail);
            if ($data) {

                $arr = ['status'=>1,'msg'=>'订单提交成功'];
                    
                $cartUpdate=[
                    'is_del'=>2,
                    'buy_number'=>0
                ];
                Cart::where('user_id',$session_id)->whereIn('goods_id',$goods_id)->update($cartUpdate);
                
                return $arr;
            }
        }     
    }



    public function orderDet(){
        $arr = DB::table('order_detail')->join('goods','goods.goods_id','=','order_detail.goods_id')->get();

        $res = DB::table('order_address')->where('status',1)->first();
        return view('goods.order',['arr'=>$arr,'res'=>$res]);
    }
}
