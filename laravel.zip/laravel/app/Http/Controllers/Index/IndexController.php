<?php

namespace App\Http\Controllers\Index;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
    // public function index(){
    //     return view('index.index.index');
    // }
    public function index(){
        // $recommend = $request->input();
        $arr = DB::table('goods')->take(2)->get();
        // print_r ($arr);exit;

        return view('index.index.index',['arr'=>$arr]);

    }

    public function addlie(Request $request){
        $arr = array();
        $page = $request->input("page",1);
        $pageNum = 2;
        $offset = ($page-1) * $pageNum;
        $arrDataInfo = DB::table("goods")->offset($offset)->limit($pageNum)->get();

        $totalData = DB::table("goods")->count();
        $pageTotal = ceil($totalData/$pageNum);

        $objview = view('index.index.addlie',['info'=>$arrDataInfo]);

        $content = response($objview)->getContent();
        $arr['info']=$content;
        $arr['page']=$pageTotal;

        return  $arr;

    }
}
