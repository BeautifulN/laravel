<?php

namespace App\Http\Controllers\Login;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class LoginController extends Controller
{
    public function login(){
        return view('index.login');
    }

    public function logadd(Request $request){
        $data=$request->input();
        $user_tel = $data['user_tel'];
        $user_pwd = $data['user_pwd'];

        $where = ['user_tel'=>$user_tel,'user_pwd'=>$user_pwd];
        $res = DB::table('index_register')->where($where)->first();
        $user_id=$res->user_id;
        // var_dump($user_id);exit;
        if ($res) {
            session(['user_id'=>$user_id]);
            return  array('status'=>1,"msg"=>"登录成功");
        }else{
            return  array('status'=>0,"msg"=>"登录失败");
        }
    }
}
