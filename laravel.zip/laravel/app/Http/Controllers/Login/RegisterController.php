<?php

namespace App\Http\Controllers\Login;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class RegisterController extends Controller
{
    public function register(){
        return view('index.register');
    }

    public function regadd(Request $request){    
        $data=$request->input();
        // print_r($data);exit;
        $user_tel=$data['user_tel'];
        $user_pwd=$data['user_pwd'];
        $user_pwds=$data['user_pwds'];
        $user_code=$data['user_code'];
        
        if($user_pwd != $user_pwds){
            $arr = array(
                'status'=>0,
                "msg"=>"密码不一致",
            );
            return $arr;
        }

        $time = time();
        $sql = "select * from user_code where tel = $user_tel and code=$user_code and timeout > $time and 'status'=1";
        $arr = DB::select($sql);
        if(!empty($arr->id)){
            $arr = array(
                'status'=>0,
                "msg"=>"验证码错误"
            );
            return $arr;
        }

        $arr = DB::table('index_register')->where('user_tel',$user_tel)->first();
        if(!empty($arr)){
            $arr = array(
                'status'=>0,
                "msg"=>"手机号已存在"
            );
            return $arr;
        }
        $info=[
           'user_tel'=>$user_tel,
            'user_pwd'=>$user_pwd
        ];

        $res=DB::table('index_register')->insert($info);
        if($res){
            echo 0;
        }else{
            echo 2;
        }
    }

    public function getcode(Request $request){
        $tel = $request->input("tel");
                // var_dump($tel);exit;
        $num = rand(1000,9999);
        $obj = new \send();
        $bol = $obj->show($tel,$num);
        if ($bol == 100) {
            $arr = array(
                'tel'=>$tel,
                'code'=>$num,
                'timeout'=>time()+360,

            );
            $bol = DB::table('user_code')->insert($arr);
            var_dump($arr);exit;
            var_dump($bol);
        }
    }

}
