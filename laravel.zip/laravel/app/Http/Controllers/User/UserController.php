<?php

namespace App\Http\Controllers\user;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Models\test;

class UserController extends Controller
{
    public function user(){
        $sql = 'select * from user_cate';
        $arr = DB::select($sql);
        return view('user.show',['arr'=>$arr]);
    }

    public function add(Request $request){    
        $data=$request->input();
        $res=DB::table('user_shop')->insert($data);
        if($res){
            echo 1;
        }else{
            echo 2;
        }
    }

    public function list(Request $request){
        $search=$request->input('search');
        if (!empty($search)) {
        $where=[
            'user_mai'=>1,
            'user_name'=>['limit',"%$search%"]
        ];
        }else{
            $where=[
                'user_mai'=>1,
            ]; 
        }
        $arr = DB::table('user_shop')
                ->join('user_cate','user_shop.c_id','=','user_cate.c_id')
                ->where($where)
                ->select()
                ->paginate(3);
                return view('user.list',['arr'=>$arr]);
    }

    public function del(Request $request){
        $del_id=$request->input('del_id');
        $spl = "update user_shop set user_mai=0 where user_id=$del_id";
        $arr=DB::update($spl);
        // print_r($arr);
        if($arr){
            echo '1';
        }else{
            echo '2';
        }
    }

    public function update(Request $request){
        $user_id=$request->input('user_id');
        $arr = DB::table('user_shop')->where('user_id','=',$user_id)->first();
        $sql="select * from user_cate";
        $res=DB::select($sql);
        return view('user.upd',['arr'=>$arr,'res'=>$res]);

    }

    public function upd(Request $request){
        $user_id = $request->input('c_id');
        $data = $request->input();
        $where=[
            'user_id'=>$user_id
        ];
        // print_r($data);exit;
        // $data = array('user_id'=>$user_id,'user_name'=>$user_name,'c_id'=>$c_id,'user_desc'=>$user_desc,'user_mai'=>$user_mai,'user_show'=>$user_show);
        $res = DB::table('user_shop')->where($where)->update($data);
        // print_r($res);
        if($res){
            echo '1';
        }else{
            echo '2';
        }
    }

    public function xiu(){

    //利用的原生的sql修改语句  修改用ajax传来的name 与  id  进行修改
            $list = DB::update("update user_shop set user_name='{$_GET['name']}' where user_id={$_GET['pid']}");
            if($list){
        
    //如果成功返回1
                echo 1;
            }
        }
}
