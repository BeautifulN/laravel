<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>购物车</title>
    <meta content="app-id=518966501" name="apple-itunes-app" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta content="telephone=no" name="format-detection" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link href="css/cartlist.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="layui/css/layui.css">
</head>
<body id="loadingPicBlock" class="g-acc-bg">
    <input name="hidUserID" type="hidden" id="hidUserID" value="-1" />
    <div>
        <!--首页头部-->
        <div class="m-block-header">
            <a href="/" class="m-public-icon m-1yyg-icon"></a>
            <a href="/" class="m-index-icon">编辑</a>
        </div>
        <!--首页头部 end-->
        <div class="g-Cart-list">

            <ul id="cartBody">
            @foreach($arr as $v)
                <li goods_selfprice="{{$v->goods_selfprice}}">
                    <s class="xuan" goods_id="{{$v->goods_id}}"></s>
                    <a class="fl u-Cart-img" href="*">
                        <img  src="{{URL::asset('goodsimg/'.$v->goods_img)}}" border="0" alt="">
                    </a>
                    <div class="u-Cart-r">
                        <a href="/v44/product/12501977.do" class="gray6">(已更新至第{{$v->goods_id}}潮){{$v->goods_name}}</a>
                        <span class="gray9">
                            <em>剩余124人次</em>价值：￥{{$v->goods_selfprice}}
                        </span>
                        <div class="num-opt">
                            
                            <em class="num-mius dis min" id="{{$v->id}}"><i></i></em>

                            <input class="text_box" name="num" maxlength="6" type="number" value="{{$v->buy_number}}" codeid="12501977" onkeyup="value=(parseInt((value=value.replace(/\D/g,''))==''||parseInt((value=value.replace(/\D/g,''))==0)?'1':value,10))" onafterpaste="value=(parseInt((value=value.replace(/\D/g,''))==''||parseInt((value=value.replace(/\D/g,''))==0)?'1':value,10))">

                            <em class="num-add add" goods_id="{{$v->goods_id}}" id="{{$v->id}}"><i></i></em>

                        </div>
                        <a href="javascript:;" name="delLink" cid="12501977" isover="0" class="z-del" id="{{$v->id}}"><s></s></a>
                    </div>    
                </li>
            @endforeach
            </ul>
            <div id="divNone" class="empty "  style="display: none"><s></s><p>您的购物车还是空的哦~</p><a href="https://m.1yyg.com" class="orangeBtn">立即潮购</a></div>
        </div>
        <div id="mycartpay" class="g-Total-bt g-car-new" style="">
            <dl>
                <dt class="gray6">
                    <s class="quanxuan"></s>全选
                    <p class="money-total">合计<em class="orange total"><span>￥</span><a id="yuan">17.00</a></em></p>
                    
                </dt>
                <dd>
                    <a href="javascript:;" id="a_payment" class="orangeBtn w_account remove">删除</a>
                    <a href="orderDet" id="a_payment" class="orangeBtn w_account sett">去结算</a>
                </dd>
            </dl>
        </div>
        <div class="hot-recom">
            <div class="title thin-bor-top gray6">
                <span><b class="z-set"></b>人气推荐</span>
                <em></em>
            </div>
            <div class="goods-wrap thin-bor-top">
                <ul class="goods-list clearfix">
                @foreach($res as $v)
                    <li>
                        <a href="https://m.1yyg.com/v44/products/23458.do" class="g-pic">
                            <img src="{{URL::asset('goodsimg/'.$v->goods_img)}}" width="136" height="136">
                        </a>
                        <p class="g-name">
                            <a href="https://m.1yyg.com/v44/products/23458.do">(第<i>{{$v->goods_id}}</i>潮){{$v->goods_name}}</a>
                        </p>
                        <ins class="gray9">价值:￥{{$v->goods_selfprice}}</ins>
                        <div class="btn-wrap">
                            <div class="Progress-bar">
                                <p class="u-progress">
                                    <span class="pgbar" style="width:1%;">
                                        <span class="pging"></span>
                                    </span>
                                </p>
                            </div>
                            <div class="gRate" data-productid="23458">
                                <a href="javascript:;"><s></s></a>
                            </div>
                        </div>
                    </li>
                @endforeach
                </ul>
            </div>
        </div>

       
        

<div class="footer clearfix">
    <ul>
        <li class="f_home"><a href="/v41/index.do" ><i></i>潮购</a></li>
        <li class="f_announced"><a href="/v41/lottery/" ><i></i>最新揭晓</a></li>
        <li class="f_single"><a href="/v41/post/index.do" ><i></i>晒单</a></li>
        <li class="f_car"><a id="btnCart" href="/v41/mycart/index.do" class="hover"><i></i>购物车</a></li>
        <li class="f_personal"><a href="/v41/member/index.do" ><i></i>我的潮购</a></li>
    </ul>
</div>
<script src="layui/layui.js"></script>
<script src="js/jquery-1.11.2.min.js"></script>
<!---商品加减算总数---->
    <script type="text/javascript">
    $(function () {
        $(".add").click(function () {
            var t = $(this).prev();
            t.val(parseInt(t.val()) + 1);
            GetCount();
        })
        $(".min").click(function () {
            var t = $(this).next();
            if(t.val()>1){
                t.val(parseInt(t.val()) - 1);
                GetCount();
            }
        })
    })

/**减 */
layui.use("layer",function(){
    var layer=layui.layer;
        $('.min').click(function(){
        _this = $(this);
        var data = {};
        var url = "cartmin";
        var id=_this.attr('id');
        var buy_number = _this.next().val();
        // alert(id);
        // alert(buy_number);
        data.buy_number = buy_number;
        data.id = id;
        $.ajax({
            type : "POST",
            data : data,
            url : url,
            success:function(msg){
                if(msg.status==1){
                

                // location.href='index';
            }else{
                layer.msg(msg.msg);
                // location.href='login';
                }  
            }
        })
    })
})

/**加 */
layui.use("layer",function(){
    var layer=layui.layer;
        $('.add').click(function(){
        _this = $(this);
        var data = {};
        var url = "cartadd";
        var id=_this.attr('id');
        var buy_number = _this.prevAll().val();
        // alert(id);
        // alert(buy_number);
        data.buy_number = buy_number;
        data.id = id;
        $.ajax({
            type : "POST",
            data : data,
            url : url,
            success:function(msg){
                if(msg.status==1){
            
                // location.href='index';
            }else{
                layer.msg(msg.msg);
                // location.href='login';
                }  
            }
        })
    })
})


    </script>
    
    <script>

    // 全选        
    $(".quanxuan").click(function () {
        if($(this).hasClass('current')){
            $(this).removeClass('current');

             $(".g-Cart-list .xuan").each(function () {
                if ($(this).hasClass("current")) {
                    $(this).removeClass("current"); 
                } else {
                    $(this).addClass("current");
                } 
            });
            GetCount();
        }else{
            $(this).addClass('current');

             $(".g-Cart-list .xuan").each(function () {
                $(this).addClass("current");
                // $(this).next().css({ "background-color": "#3366cc", "color": "#ffffff" });
            });
            GetCount();
        }     
    });
    
/**批量删除 */
    layui.use("layer",function(){
    var layer=layui.layer;
$(document).on('click','.remove',function(){
    var goods_id = [];
    $(".g-Cart-list .xuan").each(function () {
            if($(this).hasClass('current')){   
            goods=($(this).parents('li').find('s').attr('goods_id'));
            goods_id+=','+goods;
        }
        // console.log(goods_id);
    })
    $.post(
        "cartAll",
        {goods_id:goods_id},
        function(res){
            if (res.status==1) {
                // alert(1111)
                // .location.reload();
                window.location.href='addcart';
            }else{
                layer.msg(res.msg);
                window.location.href='addcart';
            }
        },
        "json"
    );
})


    //删除（单）

        $('.z-del').click(function(){
        _this = $(this);
        var data = {};
        var url = "cartDel";
        var id=_this.attr('id');
        data.id = id;
        $.ajax({
            type : "POST",
            data : data,
            url : url,
            success:function(msg){
                if(msg.status==1){
                layer.msg(msg.msg);
                window.location.reload();
                // location.href='index';
            }else{
                layer.msg(msg.msg);
                // location.href='login';
                }  
            }
        })
    })
})
    // 单选
    $(".g-Cart-list .xuan").click(function () {
        if($(this).hasClass('current')){   
            $(this).removeClass('current');
        }else{
            $(this).addClass('current');
        }
        if($('.g-Cart-list .xuan.current').length==$('#cartBody li').length){
                $('.quanxuan').addClass('current');
            }else{
                $('.quanxuan').removeClass('current');
            }
        // $("#total2").html() = GetCount($(this));
        GetCount();
        //alert(conts);
    });


  // 已选中的总额
    function GetCount() {
        var conts = 0;
        var aa = 0; 
        $(".g-Cart-list .xuan").each(function () {
            if ($(this).hasClass("current")) {
                for (var i = 0; i < $(this).length; i++) {
                    conts += parseInt($(this).parents('li').find('input.text_box').val())*parseInt($(this).parents('li').attr('goods_selfprice'));     
                    // aa += 1;
                }
            }
        });
        $(".total").html('<span>￥</span>'+(conts).toFixed(2));
    }
    GetCount();
</script>
</body>
</html>
<script>

    /**结算 */
layui.use("layer",function(){
var layer=layui.layer;
    $(document).on('click','.sett',function(){
            var goods_id = [];
            // yuan = $('#yuan').html();
        $(".g-Cart-list .xuan").each(function () {
                if($(this).hasClass('current')){ 
                goods=($(this).parents('li').find('s').attr('goods_id'));
                goods_id+=','+goods;
            }
        })
        // alert(goods_id);
        $.post(
            "order",
            {goods_id:goods_id},
            function(res){
                if (res.status==1) {
                    layer.msg(res.msg);
                    // .location.reload();
                    window.location.href='orderDet';
                }else{
                    layer.msg(res.msg);
                    // window.location.href='addcart';
                }
            },
            "json"
        );
    })
})

</script>
