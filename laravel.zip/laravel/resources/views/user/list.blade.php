<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        ul li {
                list-style: none;
                float: left;
                font-size: 30px;
                margin-left: 50px;
            }
    </style>
</head>
<body>
<form role="search" id="searchform">
   <input type="search" name="keyword" placeholder="关键字">
   <button type="submit" class="search">嗖嗖嗖<span class="ion-ios-search-strong"></span></button>
</form>
    <table border=1>
        <tr>
            <td>id</td>
            <td>名称</td>
            <td>分类</td>
            <td>描述</td>
            <td>是否热卖</td>
            <td>是否上架</td>
            <td>操作</td>
        </tr>
        @foreach ($arr as $v)
        <tr del_id={{ $v->user_id }}>





            <td>{{ $v->user_id }}</td>
                <!-- {{ $v->user_name }} -->

            <td pid="{{$v->user_id}}" >
                <span class="name">{{$v->user_name}}</span>
            </td>
            <td>{{ $v->c_name }}</td>
            <td>{{ $v->user_desc }}</td>
            <td>
                @if ($v->user_mai == 1)
                    是
                @else
                    否
                @endif
            </td>
            <td>
                @if ($v->user_show == 1)
                    是
                @else
                    否
                @endif
            </td>
            <td>
                <a href="javascript:;" class="del">删除</a>
                <a href="javascript:;" class="update">修改</a>
            </td>
        </tr>
        @endforeach
    </table>
    {{ $arr->links() }}  
</body>
</html>
<script src="js/jquery-3.2.1.min.js"></script>
<script>
    $(function(){
        $('.del').click(function(){
            _this=$(this)
            del_id=_this.parents('tr').attr('del_id')
            $.ajax({
                url:'del',
                data:{del_id:del_id},
                method:'post',}).done(function (res) {
                if(res==1){
                    alert('删除成功');
                    location.href='list';
                }else{
                    alert('删除失败');
                    location.href='list';
                }
            })
        });

        $('.update').click(function(){
            _this=$(this)
            user_id=_this.parents('tr').attr('del_id')
            location.href='update?user_id='+user_id;

        });




$('.name').click(function () {
//获得当前的pid
        var pid=$(this).parent().attr('pid');
        //alert(pid);
        var html=$(this).html();
//当点击的时候，触发点击事件 ，创建一个input框  默认值value为获取来的值
        $(this).parent().html("<input type='text' value="+html+" class='input'>");
//获取焦点
        $('input').focus();
 
//失去焦点
        $(document).on('blur','.input',function () {
          var name = $(this).val();
          pid = $(this).parent().attr('pid');
          $.ajax({
 
//将值传入news_shier的路由中
              url:"{{url('news_shier')}}",
              data:{name:name,pid:pid},
              type:"get",
              success:function (a) {
 
              }
 
          })
          
//0秒刷新  用来完成失去焦点之后自动    
            location.reload(0);
        })
    })

$('.search').click(function(){
            _this=$(this)
            search=_this.parents('tr').attr('del_id')
            $.ajax({
                url:'list',
                data:{search:search},
                method:'post',}).done(function (res) {
                    console.log(res);
            })
        })
})



</script>