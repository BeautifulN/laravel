<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('hello', function () {
    return '画斛黄花寒更好';
});

Route::any('user', 'User\UserController@user');

// Route::any('user', 'User\UserController@user');
// Route::post('add', 'User\UserController@add');
// Route::get('list', 'User\UserController@list');
// Route::post('del', 'User\UserController@del');
// Route::any('update', 'User\UserController@update');
// Route::any('upd', 'User\UserController@upd');
// Route::get('/list','User\UserController@list');
// Route::post('/list','User\UserController@list');
// Route::get('news_shier',"User\UserController@xiu");


Route::get('register',"Login\RegisterController@register");
Route::post('regadd',"Login\RegisterController@regadd");

Route::post('getcode',"Login\RegisterController@getcode");

Route::get('login',"Login\LoginController@login");
Route::post('logadd',"Login\LoginController@logadd");

Route::get('index',"Index\IndexController@index");
Route::post('addlie',"Index\IndexController@addlie");

Route::get('all',"Goods\GoodsController@all");
Route::post('cons',"Goods\GoodsController@cons");

Route::any('content',"Goods\ContentController@content");
Route::post('cart',"Goods\ContentController@cart");
Route::get('addcart',"Goods\CartController@addcart");
Route::post('cartDel',"Goods\CartController@cartDel");
Route::post('cartmin',"Goods\CartController@cartmin");
Route::post('cartadd',"Goods\CartController@cartadd");
Route::post('cartAll',"Goods\CartController@cartAll");
Route::post('order',"Goods\OrderController@order");

Route::get('orderDet',"Goods\OrderController@orderDet");
Route::get('address',"Goods\AddressController@address");
Route::get('site',"Goods\AddressController@site");
Route::post('siteadd',"Goods\AddressController@siteadd");
Route::post('addressDel',"Goods\AddressController@addressDel");
Route::any('addupd',"Goods\AddressController@addupd");
Route::post('addressupd',"Goods\AddressController@addressupd");
Route::post('defalt',"Goods\AddressController@defalt");

Route::get('myspace',"Goods\MyspaceController@myspace");














