<?php
    echo $name;
?>