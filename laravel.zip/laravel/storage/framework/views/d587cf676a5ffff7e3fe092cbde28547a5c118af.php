<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="" class="show">
        
        <input type="hidden" name="user_id" value="<?php echo $arr->user_id?>">
        <table> 
            <tr>
                <td>名称：</td>
                <td><input type="text" name="user_name" value="<?php echo $arr->user_name ?>" id="user_name"></td>
            </tr>
            <tr>
                <td>分类：</td>
                <td>
                    <select name="c_name" id="c_id">
                    <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($arr->c_id == $v->c_id): ?>
                        <option value="<?php echo e($v->c_id); ?>" ><?php echo e($v->c_name); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($v->c_id); ?>"><?php echo e($v->c_name); ?></option>
                    <?php endif; ?>               
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>描述：</td>
                <td>
                    <textarea name="user_desc" id="user_desc" value="<?php echo $arr->user_desc ?>" id="" cols="30" rows="10"></textarea>
                </td>
            </tr>
            <tr>
                <td>是否热卖</td>
                <td>
                    <?php if($arr->c_id == 1): ?>
                        是<input type="radio" name="user_mai" value=1>
                        否<input type="radio" name="user_mai" value=0>
                    <?php else: ?>
                        是<input type="radio" name="user_mai" value=1>
                        否<input type="radio" name="user_mai" value=0>
                    <?php endif; ?> 
                   
                    
                </td>
            </tr>
            <tr>
                <td>是否上架</td>
                <td>
                <?php if($arr->user_show == 1): ?>
                    是<input type="radio" name="user_show" value=1>
                    否<input type="radio" name="user_show" value=0>
                <?php else: ?>
                    是<input type="radio" name="user_show" value=1>
                    否<input type="radio" name="user_show" value=0>
                <?php endif; ?>
                    
                </td>
            </tr>
            <tr>
                <td></td>
                <td><input type="button" value="修改" class="submit"></td>
            </tr>
        </table>
    </form>
</body>
</html>
<script src="js/jquery-3.2.1.min.js"></script>
<script>
    $(function(){
        $('.submit').click(function(){
            var user_name=$('#user_name').val();
            var c_id=$('#c_id').val();
            var user_desc=$('#user_desc').val();
            var user_mai=$("input[name='user_mai']:checked").val();
            var user_show=$("input[name='user_show']:checked").val();
            $.ajax({
                url:'upd',
                data:{user_name:user_name,c_id:c_id,user_desc:user_desc,user_mai:user_mai,user_show:user_show},
                method:'post',}).done(function (res) {
                if(res==1){
                    alert('修改成功');
                    // location.href='list';
                }else{
                    alert('修改失败');
                    // location.href='upd';
                }
            })
        });
    })
</script>

